-- models/social_media_metrics/engagement_over_time_by_platform.sql

-- Engagement over time by platform
-- Combines likes and replies (comments) from Instagram, X (Twitter), and Post Objectives

SELECT
    date,
    platform,
    SUM(total_likes) AS daily_likes,
    SUM(total_replies) AS daily_replies,
    SUM(total_retweets_quotes) AS daily_retweets_quotes
FROM (
    SELECT
        DATE_TRUNC(DATETIME(timestamp), DAY) AS date, -- Convert string to DATETIME first
        'Instagram' AS platform,
        like_count AS total_likes,
        replies AS total_replies,
        NULL AS total_retweets_quotes
    FROM
        {{ source('social_media_metrics', 'cleaned_instagram_data') }}
    WHERE timestamp IS NOT NULL -- Filter out null timestamps

    UNION ALL

    SELECT
        DATE_TRUNC(DATETIME(created_at), DAY) AS date, -- Convert string to DATETIME first
        'X (Twitter)' AS platform,
        like_count AS total_likes,
        reply_count AS total_replies,
        (retweet_count + quote_count) AS total_retweets_quotes -- Combine retweets and quotes
    FROM
        {{ source('social_media_metrics', 'cleaned_tweets_data') }}
    WHERE created_at IS NOT NULL -- Filter out null timestamps

    UNION ALL

    SELECT
        DATE_TRUNC(DATETIME(actual_post_date), DAY) AS date, -- Convert DATE to DATETIME first
        platform AS platform,
        actual_likes AS total_likes,
        actual_comments AS total_replies, -- Assuming comments = replies here
        NULL AS total_retweets_quotes
    FROM
        {{ source('social_media_metrics', 'cleaned_post_metrics_objectives') }}
    WHERE actual_post_date IS NOT NULL -- Filter out null dates
) AS combined_engagement
GROUP BY
    date,
    platform
ORDER BY
    date,
    platform