{{ config(materialized='table') }}
SELECT   
    contract_id,
    influencer_id,
    campaign_id,
    total_fee,
    sign_date,
    payment_due_days,
    payment_status,
    termination_allowed,
    post_duration_days,
    contract_status,
    compliance,      
    final_amount,    
    currency,
    post_required         -- Removed the comma here
FROM {{ source('social_media_metrics', 'cleaned_contract') }}