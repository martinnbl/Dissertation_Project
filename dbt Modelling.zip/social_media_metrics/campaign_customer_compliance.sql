-- Compliance by Customer and Campaign
SELECT
    c.Customer_name,
    cam.Campaign_name,
    pmo.platform,
    COUNT(pmo.post_id) AS total_posts,
    SUM(CASE WHEN pmo.qualified THEN 1 ELSE 0 END) AS compliant_posts_by_objectives,
    SUM(CASE WHEN pmo.screenshot_received THEN 1 ELSE 0 END) AS posts_with_screenshots,
    (SUM(CASE WHEN pmo.qualified THEN 1 ELSE 0 END) * 100.0 / COUNT(pmo.post_id)) AS compliance_rate_objectives,
    (SUM(CASE WHEN pmo.screenshot_received THEN 1 ELSE 0 END) * 100.0 / COUNT(pmo.post_id)) AS screenshot_receipt_rate
FROM
    `proof-of-brand.social_media_metrics.cleaned_post_metrics_objectives` AS pmo
LEFT JOIN
    `proof-of-brand.social_media_metrics.cleaned_contract` AS co
    ON pmo.contract_ids = co.contract_id
LEFT JOIN
    `proof-of-brand.social_media_metrics.cleaned_customer` AS c
    ON co.influencer_id = c.Customer_id -- Assuming influencer_id in contract maps to Customer_id
LEFT JOIN
    `proof-of-brand.social_media_metrics.cleaned_campaigns` AS cam
    ON co.campaign_id = cam.Campaign_id
GROUP BY
    c.Customer_name,
    cam.Campaign_name,
    pmo.platform
ORDER BY
    c.Customer_name, cam.Campaign_name