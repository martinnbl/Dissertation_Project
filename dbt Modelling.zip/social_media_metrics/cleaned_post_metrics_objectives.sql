{{ config(materialized='table') }}

SELECT 
  post_id,
  contract_ids,
  platform,
  scheduled_date,
  content_theme,
  impressions_target,
  likes_target,
  comments_target,
  actual_impressions,
  actual_likes,
  actual_comments,
  qualified,
  screenshot_received,
  sentiment_score,
  platform_post_id,
  influencer_id,
  actual_post_date
FROM {{ source('social_media_metrics', 'cleaned_post_metrics_objectives') }}