SELECT 
  -- Post Performance (from cleaned_post_metrics_objectives)
  pmo.post_id,
  pmo.contract_ids,
  pmo.platform,
  pmo.scheduled_date,
  pmo.content_theme,
  pmo.actual_post_date,
  pmo.influencer_id,
  pmo.platform_post_id,
  
  -- Targets
  SAFE_CAST(pmo.impressions_target AS INT64) AS impressions_target,
  SAFE_CAST(pmo.likes_target AS INT64) AS likes_target,
  SAFE_CAST(pmo.comments_target AS INT64) AS comments_target,
  
  -- Actuals
  SAFE_CAST(pmo.actual_impressions AS INT64) AS actual_impressions,
  SAFE_CAST(pmo.actual_likes AS INT64) AS actual_likes,
  SAFE_CAST(pmo.actual_comments AS INT64) AS actual_comments,
  
  -- Flags & Sentiment
  pmo.qualified,
  pmo.screenshot_received,
  SAFE_CAST(pmo.sentiment_score AS FLOAT64) AS sentiment_score,
  
  -- Contract Info
  ct.contract_id,
  ct.influencer_id AS contract_influencer_id,
  ct.campaign_id,
  SAFE_CAST(ct.total_fee AS FLOAT64) AS contract_total_fee,
  SAFE_CAST(ct.final_amount AS FLOAT64) AS contract_final_amount,
  ct.payment_status,
  ct.contract_status,
  SAFE_CAST(ct.compliance AS FLOAT64) AS contract_compliance,
  ct.sign_date,
  SAFE_CAST(ct.payment_due_days AS INT64) AS payment_due_days,
  ct.termination_allowed,
  SAFE_CAST(ct.post_duration_days AS INT64) AS post_duration_days,
  SAFE_CAST(ct.post_required AS INT64) AS posts_required,
  ct.currency AS contract_currency,
  
  -- Campaign Info
  c.Campaign_name,
  c.Type AS campaign_type,
  c.Status AS campaign_status,
  c.Start_date AS campaign_start_date,
  c.End_date AS campaign_end_date,
  c.Customer_id AS campaign_customer_id,
  c.Platform AS campaign_platform,
  c.Business_objective,
  c.Target AS campaign_target,
  c.Milestone AS campaign_milestone,
  
  -- Customer Info
  cust.Customer_name,
  cust.Customer_type,
  cust.Acquisition_date AS customer_acquisition_date,
  cust.Industry AS customer_industry,
  cust.Segment AS customer_segment,
  cust.Country AS customer_country,
  cust.Region AS customer_region,
  cust.Status AS customer_status,
  cust.Platform AS customer_platform,
  cust.Username AS customer_username,
  
  -- Payment Queue Info
  pq.amount AS queued_payment_amount,
  pq.created_at AS payment_queued_at,
  pq.processed_at AS payment_processed_at,
  pq.currency AS payment_currency,
  pq.status AS payment_queue_status,

  -- === CALCULATED METRICS ===

  -- Achievement Percentages
  CASE 
    WHEN SAFE_CAST(pmo.impressions_target AS INT64) > 0 
    THEN ROUND((SAFE_CAST(pmo.actual_impressions AS FLOAT64) / SAFE_CAST(pmo.impressions_target AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS impressions_achievement_pct,
  
  CASE 
    WHEN SAFE_CAST(pmo.likes_target AS INT64) > 0 
    THEN ROUND((SAFE_CAST(pmo.actual_likes AS FLOAT64) / SAFE_CAST(pmo.likes_target AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS likes_achievement_pct,
  
  CASE 
    WHEN SAFE_CAST(pmo.comments_target AS INT64) > 0 
    THEN ROUND((SAFE_CAST(pmo.actual_comments AS FLOAT64) / SAFE_CAST(pmo.comments_target AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS comments_achievement_pct,

  -- Overall Achievement %
  ROUND((
    COALESCE(CASE WHEN SAFE_CAST(pmo.impressions_target AS INT64) > 0 THEN (SAFE_CAST(pmo.actual_impressions AS FLOAT64) / SAFE_CAST(pmo.impressions_target AS FLOAT64)) END, 0) +
    COALESCE(CASE WHEN SAFE_CAST(pmo.likes_target AS INT64) > 0 THEN (SAFE_CAST(pmo.actual_likes AS FLOAT64) / SAFE_CAST(pmo.likes_target AS FLOAT64)) END, 0) +
    COALESCE(CASE WHEN SAFE_CAST(pmo.comments_target AS INT64) > 0 THEN (SAFE_CAST(pmo.actual_comments AS FLOAT64) / SAFE_CAST(pmo.comments_target AS FLOAT64)) END, 0)
  ) / NULLIF(
    (CASE WHEN SAFE_CAST(pmo.impressions_target AS INT64) > 0 THEN 1 ELSE 0 END) +
    (CASE WHEN SAFE_CAST(pmo.likes_target AS INT64) > 0 THEN 1 ELSE 0 END) +
    (CASE WHEN SAFE_CAST(pmo.comments_target AS INT64) > 0 THEN 1 ELSE 0 END),
    0
  ) * 100, 1) AS overall_achievement_pct,

  -- Financial Adjustment
  CASE 
    WHEN SAFE_CAST(ct.total_fee AS FLOAT64) > 0 
    THEN ROUND((SAFE_CAST(ct.final_amount AS FLOAT64) / SAFE_CAST(ct.total_fee AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS payment_adjustment_pct,

  -- Date Calculations
  DATE_DIFF(CURRENT_DATE(), DATE(pmo.scheduled_date), DAY) AS days_since_scheduled,

  CASE 
    WHEN pmo.actual_post_date IS NOT NULL AND pmo.scheduled_date IS NOT NULL
    THEN DATE_DIFF(DATE(pmo.actual_post_date), DATE(pmo.scheduled_date), DAY)
    ELSE NULL
  END AS days_late_posted,

  -- Status Tags
  CASE 
    WHEN pmo.qualified THEN 'Qualified'
    WHEN SAFE_CAST(pmo.actual_impressions AS INT64) IS NOT NULL THEN 'Posted - Not Qualified'
    ELSE 'Not Posted'
  END AS performance_status,

  CASE 
    WHEN SAFE_CAST(ct.compliance AS FLOAT64) >= 0.95 THEN 'Excellent'
    WHEN SAFE_CAST(ct.compliance AS FLOAT64) >= 0.85 THEN 'Good'
    WHEN SAFE_CAST(ct.compliance AS FLOAT64) >= 0.70 THEN 'Acceptable'
    ELSE 'Poor'
  END AS compliance_grade,

  -- Payment Status Summary
  CASE 
    WHEN ct.payment_status = 'Paid' THEN 'Complete'
    WHEN pq.status = 'PENDING' THEN 'In Queue'
    WHEN ct.payment_status = 'Pending' THEN 'Awaiting Queue'
    ELSE 'Unknown'
  END AS payment_summary_status

FROM {{ source('social_media_metrics', 'cleaned_post_metrics_objectives') }} pmo

LEFT JOIN {{ source('social_media_metrics', 'cleaned_contract') }} ct 
  ON pmo.contract_ids = ct.contract_id

LEFT JOIN {{ source('social_media_metrics', 'cleaned_campaigns') }} c 
  ON ct.campaign_id = c.Campaign_id

LEFT JOIN {{ source('social_media_metrics', 'cleaned_customer') }} cust 
  ON ct.influencer_id = cust.Customer_id

LEFT JOIN {{ source('social_media_metrics', 'cleaned_payment_queue') }} pq 
  ON ct.contract_id = pq.contract_id
