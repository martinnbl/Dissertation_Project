{{ config(materialized='table') }}

SELECT 
  Campaign_id,
  Campaign_name,
  Type,
  Status,
  Start_date,
  End_date,
  Customer_id,
  Platform,
  Business_objective,
  Target,
  Milestone
FROM {{ source('social_media_metrics', 'cleaned_campaigns') }}