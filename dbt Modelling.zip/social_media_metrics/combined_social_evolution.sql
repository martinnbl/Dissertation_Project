-- models/social_media_metrics/combined_social_evolution.sql

-- Likes, Reach, Views, Impressions evolution over time
-- This query combines metrics from Instagram, X (Twitter), and Post Objectives
-- It assumes relevant date columns for grouping.

SELECT
    DATE_TRUNC(DATETIME(timestamp), DAY) AS date, -- Convert string to DATETIME first
    'Instagram' AS platform,
    SUM(like_count) AS total_likes,
    SUM(reach) AS total_reach,
    SUM(video_views) AS total_video_views,
    SUM(views) AS total_views,
    NULL AS total_impressions -- Impressions not directly in Instagram data for posts
FROM
    {{ source('social_media_metrics', 'cleaned_instagram_data') }}
WHERE timestamp IS NOT NULL -- Filter out null timestamps
GROUP BY
    1, 2

UNION ALL

SELECT
    DATE_TRUNC(DATETIME(created_at), DAY) AS date, -- Convert string to DATETIME first
    'X (Twitter)' AS platform,
    SUM(like_count) AS total_likes,
    NULL AS total_reach, -- Reach not directly in X data
    NULL AS total_video_views,
    NULL AS total_views,
    NULL AS total_impressions -- Impressions not directly in X data
FROM
    {{ source('social_media_metrics', 'cleaned_tweets_data') }}
WHERE created_at IS NOT NULL -- Filter out null timestamps
GROUP BY
    1, 2

UNION ALL

SELECT
    DATE_TRUNC(DATETIME(actual_post_date), DAY) AS date, -- Convert DATE to DATETIME first
    platform AS platform, -- Assuming 'platform' column exists here
    SUM(actual_likes) AS total_likes,
    NULL AS total_reach,
    NULL AS total_video_views,
    NULL AS total_views,
    SUM(actual_impressions) AS total_impressions
FROM
    {{ source('social_media_metrics', 'cleaned_post_metrics_objectives') }}
WHERE actual_post_date IS NOT NULL -- Filter out null dates
GROUP BY
    1, 2
ORDER BY
    date, platform