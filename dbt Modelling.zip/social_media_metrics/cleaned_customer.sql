{{ config(materialized='table') }}

SELECT 
  Customer_name,
  Customer_id,
  Customer_type,
  Acquisition_date,
  Industry,
  Segment,
  Country,
  Region,
  Status,
  Platform,
  Username
FROM {{ source('social_media_metrics', 'cleaned_customer') }}