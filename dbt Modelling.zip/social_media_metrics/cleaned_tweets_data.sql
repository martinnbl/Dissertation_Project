{{ config(materialized='table') }}

SELECT 
  tweet_id,
  text,
  created_at,
  like_count,
  retweet_count,
  reply_count,
  quote_count,
  Platform
FROM {{ source('social_media_metrics', 'cleaned_tweets_data') }}