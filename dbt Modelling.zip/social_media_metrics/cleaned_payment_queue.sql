{{ config(materialized='table') }}
SELECT   
    contract_id,
    amount,
    created_at,
    processed_at,
    currency,
    status
FROM {{ source('social_media_metrics', 'cleaned_payment_queue') }}