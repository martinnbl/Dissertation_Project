-- Enhanced Dashboard Master Table with Latest Social Media Metrics
-- This model integrates the most recent social media performance data
-- for comprehensive campaign and contract tracking

WITH latest_instagram_metrics AS (
  -- Get the most recent reading for each Instagram post
  SELECT 
    id as platform_post_id,
    'Instagram' as platform,
    username,
    permalink,
    caption,
    timestamp as last_updated,
    like_count as latest_likes,
    reach as latest_reach,
    COALESCE(reach, views) as latest_impressions, -- Use reach as impressions, fallback to views
    replies as latest_comments,
    video_views as latest_video_views,
    plays as latest_plays,
    total_interactions as latest_total_interactions,
    media_type,
    media_category
  FROM (
    SELECT *,
      ROW_NUMBER() OVER (PARTITION BY id ORDER BY timestamp DESC) as rn
    FROM {{ source('social_media_metrics', 'cleaned_instagram_data') }}
  ) 
  WHERE rn = 1
),

latest_twitter_metrics AS (
  -- Get the most recent reading for each Twitter/X post
  SELECT 
    tweet_id as platform_post_id,
    'X' as platform,
    NULL as username, -- Will get from customer table
    NULL as permalink,
    text as caption,
    created_at as last_updated,
    like_count as latest_likes,
    NULL as latest_reach,
    NULL as latest_impressions, -- Twitter doesn't provide impression data via basic API
    reply_count as latest_comments,
    NULL as latest_video_views,
    NULL as latest_plays,
    (like_count + retweet_count + reply_count + quote_count) as latest_total_interactions,
    'TWEET' as media_type,
    'Social' as media_category,
    retweet_count as latest_retweets,
    quote_count as latest_quotes
  FROM (
    SELECT *,
      ROW_NUMBER() OVER (PARTITION BY tweet_id ORDER BY created_at DESC) as rn
    FROM {{ source('social_media_metrics', 'cleaned_tweets_data') }}
  )
  WHERE rn = 1
),

-- Combine all latest social media metrics
latest_social_metrics AS (
  SELECT 
    platform_post_id,
    platform,
    username,
    permalink,
    caption,
    last_updated,
    latest_likes,
    latest_reach,
    latest_impressions,
    latest_comments,
    latest_video_views,
    latest_plays,
    latest_total_interactions,
    media_type,
    media_category,
    NULL as latest_retweets,
    NULL as latest_quotes
  FROM latest_instagram_metrics
  
  UNION ALL
  
  SELECT 
    platform_post_id,
    platform,
    username,
    permalink,
    caption,
    last_updated,
    latest_likes,
    latest_reach,
    latest_impressions,
    latest_comments,
    latest_video_views,
    latest_plays,
    latest_total_interactions,
    media_type,
    media_category,
    latest_retweets,
    latest_quotes
  FROM latest_twitter_metrics
),

-- Get sentiment data for social posts
post_sentiment AS (
  SELECT 
    tweet as post_text,
    sentiment,
    confidence as sentiment_confidence,
    Platform
  FROM {{ source('social_media_metrics', 'cleaned_tweets_sentiment_data') }}
)

-- Main query combining all data sources
SELECT 
  -- === POST IDENTIFICATION ===
  pmo.post_id,
  pmo.contract_ids as contract_id,
  pmo.platform,
  pmo.scheduled_date,
  pmo.content_theme,
  pmo.actual_post_date,
  pmo.influencer_id,
  pmo.platform_post_id,
  
  -- === ORIGINAL TARGETS ===
  SAFE_CAST(pmo.impressions_target AS INT64) AS impressions_target,
  SAFE_CAST(pmo.likes_target AS INT64) AS likes_target,
  SAFE_CAST(pmo.comments_target AS INT64) AS comments_target,
  
  -- === STORED ACTUALS (from post metrics objectives) ===
  SAFE_CAST(pmo.actual_impressions AS INT64) AS stored_impressions,
  SAFE_CAST(pmo.actual_likes AS INT64) AS stored_likes,
  SAFE_CAST(pmo.actual_comments AS INT64) AS stored_comments,
  
  -- === LATEST SOCIAL MEDIA METRICS ===
  sm.latest_likes,
  sm.latest_impressions,
  sm.latest_comments,
  sm.latest_reach,
  sm.latest_video_views,
  sm.latest_total_interactions,
  sm.latest_retweets,
  sm.latest_quotes,
  sm.last_updated as social_metrics_last_updated,
  sm.media_type,
  sm.media_category,
  sm.caption as social_post_caption,
  sm.permalink as social_post_url,
  
  -- === PERFORMANCE FLAGS ===
  pmo.qualified as originally_qualified,
  pmo.screenshot_received,
  SAFE_CAST(pmo.sentiment_score AS FLOAT64) AS stored_sentiment_score,
  
  -- === LATEST SENTIMENT DATA ===
  ps.sentiment as latest_sentiment,
  ps.sentiment_confidence as latest_sentiment_confidence,
  
  -- === CONTRACT INFORMATION ===
  ct.contract_id as contract_reference,
  ct.influencer_id AS contract_influencer_id,
  ct.campaign_id,
  SAFE_CAST(ct.total_fee AS FLOAT64) AS contract_total_fee,
  SAFE_CAST(ct.final_amount AS FLOAT64) AS contract_final_amount,
  ct.payment_status,
  ct.contract_status,
  SAFE_CAST(ct.compliance AS FLOAT64) AS contract_compliance,
  ct.sign_date as contract_sign_date,
  SAFE_CAST(ct.payment_due_days AS INT64) AS payment_due_days,
  ct.termination_allowed,
  SAFE_CAST(ct.post_duration_days AS INT64) AS post_duration_days,
  SAFE_CAST(ct.post_required AS INT64) AS posts_required,
  ct.currency AS contract_currency,
  
  -- === CAMPAIGN INFORMATION ===
  c.Campaign_name as campaign_name,
  c.Type AS campaign_type,
  c.Status AS campaign_status,
  c.Start_date AS campaign_start_date,
  c.End_date AS campaign_end_date,
  c.Customer_id AS campaign_customer_id,
  c.Platform AS campaign_platform,
  c.Business_objective,
  c.Target AS campaign_target,
  c.Milestone AS campaign_milestone,
  
  -- === CUSTOMER INFORMATION ===
  cust.Customer_name as customer_name,
  cust.Customer_type,
  cust.Acquisition_date AS customer_acquisition_date,
  cust.Industry AS customer_industry,
  cust.Segment AS customer_segment,
  cust.Country AS customer_country,
  cust.Region AS customer_region,
  cust.Status AS customer_status,
  cust.Platform AS customer_platform,
  cust.Username AS customer_username,
  
  -- === PAYMENT QUEUE INFORMATION ===
  pq.amount AS queued_payment_amount,
  pq.created_at AS payment_queued_at,
  pq.processed_at AS payment_processed_at,
  pq.currency AS payment_currency,
  pq.status AS payment_queue_status,

  -- === CALCULATED METRICS - BASED ON LATEST SOCIAL DATA ===
  
  -- Current Achievement Percentages (using latest metrics)
  CASE 
    WHEN SAFE_CAST(pmo.impressions_target AS INT64) > 0 
    THEN ROUND((COALESCE(sm.latest_impressions, SAFE_CAST(pmo.actual_impressions AS FLOAT64), 0) / SAFE_CAST(pmo.impressions_target AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS impressions_achievement_pct,
  
  CASE 
    WHEN SAFE_CAST(pmo.likes_target AS INT64) > 0 
    THEN ROUND((COALESCE(sm.latest_likes, SAFE_CAST(pmo.actual_likes AS FLOAT64), 0) / SAFE_CAST(pmo.likes_target AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS likes_achievement_pct,
  
  CASE 
    WHEN SAFE_CAST(pmo.comments_target AS INT64) > 0 
    THEN ROUND((COALESCE(sm.latest_comments, SAFE_CAST(pmo.actual_comments AS FLOAT64), 0) / SAFE_CAST(pmo.comments_target AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS comments_achievement_pct,

  -- Overall Achievement % (based on latest metrics)
  ROUND((
    COALESCE(
      CASE WHEN SAFE_CAST(pmo.impressions_target AS INT64) > 0 
      THEN (COALESCE(sm.latest_impressions, SAFE_CAST(pmo.actual_impressions AS FLOAT64), 0) / SAFE_CAST(pmo.impressions_target AS FLOAT64)) 
      END, 0) +
    COALESCE(
      CASE WHEN SAFE_CAST(pmo.likes_target AS INT64) > 0 
      THEN (COALESCE(sm.latest_likes, SAFE_CAST(pmo.actual_likes AS FLOAT64), 0) / SAFE_CAST(pmo.likes_target AS FLOAT64)) 
      END, 0) +
    COALESCE(
      CASE WHEN SAFE_CAST(pmo.comments_target AS INT64) > 0 
      THEN (COALESCE(sm.latest_comments, SAFE_CAST(pmo.actual_comments AS FLOAT64), 0) / SAFE_CAST(pmo.comments_target AS FLOAT64)) 
      END, 0)
  ) / NULLIF(
    (CASE WHEN SAFE_CAST(pmo.impressions_target AS INT64) > 0 THEN 1 ELSE 0 END) +
    (CASE WHEN SAFE_CAST(pmo.likes_target AS INT64) > 0 THEN 1 ELSE 0 END) +
    (CASE WHEN SAFE_CAST(pmo.comments_target AS INT64) > 0 THEN 1 ELSE 0 END),
    0
  ) * 100, 1) AS overall_achievement_pct,

  -- Performance Growth Analysis
  CASE 
    WHEN sm.latest_likes > SAFE_CAST(pmo.actual_likes AS INT64) THEN 'Growing'
    WHEN sm.latest_likes < SAFE_CAST(pmo.actual_likes AS INT64) THEN 'Declining'
    WHEN sm.latest_likes = SAFE_CAST(pmo.actual_likes AS INT64) THEN 'Stable'
    ELSE 'No Data'
  END AS engagement_trend,

  -- Growth metrics
  COALESCE(sm.latest_likes, 0) - COALESCE(SAFE_CAST(pmo.actual_likes AS INT64), 0) AS likes_growth,
  COALESCE(sm.latest_impressions, 0) - COALESCE(SAFE_CAST(pmo.actual_impressions AS INT64), 0) AS impressions_growth,
  COALESCE(sm.latest_comments, 0) - COALESCE(SAFE_CAST(pmo.actual_comments AS INT64), 0) AS comments_growth,

  -- Current Qualification Status (based on latest metrics)
  CASE 
    WHEN COALESCE(sm.latest_impressions, SAFE_CAST(pmo.actual_impressions AS INT64), 0) >= SAFE_CAST(pmo.impressions_target AS INT64)
     AND COALESCE(sm.latest_likes, SAFE_CAST(pmo.actual_likes AS INT64), 0) >= SAFE_CAST(pmo.likes_target AS INT64)
     AND COALESCE(sm.latest_comments, SAFE_CAST(pmo.actual_comments AS INT64), 0) >= SAFE_CAST(pmo.comments_target AS INT64)
    THEN TRUE 
    ELSE FALSE 
  END AS currently_qualified,

  -- === FINANCIAL CALCULATIONS ===
  CASE 
    WHEN SAFE_CAST(ct.total_fee AS FLOAT64) > 0 
    THEN ROUND((SAFE_CAST(ct.final_amount AS FLOAT64) / SAFE_CAST(ct.total_fee AS FLOAT64)) * 100, 1)
    ELSE NULL 
  END AS payment_adjustment_pct,

  -- === DATE CALCULATIONS ===
  DATE_DIFF(CURRENT_DATE(), DATE(pmo.scheduled_date), DAY) AS days_since_scheduled,

  CASE 
    WHEN pmo.actual_post_date IS NOT NULL AND pmo.scheduled_date IS NOT NULL
    THEN DATE_DIFF(DATE(pmo.actual_post_date), DATE(pmo.scheduled_date), DAY)
    ELSE NULL
  END AS days_late_posted,

  DATE_DIFF(CURRENT_DATE(), sm.last_updated, DAY) AS days_since_last_social_update,

  -- === STATUS CLASSIFICATIONS ===
  
  -- Performance Status (based on current metrics)
  CASE 
    WHEN COALESCE(sm.latest_impressions, SAFE_CAST(pmo.actual_impressions AS INT64), 0) >= SAFE_CAST(pmo.impressions_target AS INT64)
     AND COALESCE(sm.latest_likes, SAFE_CAST(pmo.actual_likes AS INT64), 0) >= SAFE_CAST(pmo.likes_target AS INT64)
     AND COALESCE(sm.latest_comments, SAFE_CAST(pmo.actual_comments AS INT64), 0) >= SAFE_CAST(pmo.comments_target AS INT64)
    THEN 'Qualified'
    WHEN sm.latest_likes IS NOT NULL OR SAFE_CAST(pmo.actual_impressions AS INT64) IS NOT NULL 
    THEN 'Posted - Not Qualified'
    ELSE 'Not Posted'
  END AS performance_status,

  -- Compliance Grade
  CASE 
    WHEN SAFE_CAST(ct.compliance AS FLOAT64) >= 0.95 THEN 'Excellent'
    WHEN SAFE_CAST(ct.compliance AS FLOAT64) >= 0.85 THEN 'Good'
    WHEN SAFE_CAST(ct.compliance AS FLOAT64) >= 0.70 THEN 'Acceptable'
    ELSE 'Poor'
  END AS compliance_grade,

  -- Payment Status Summary
  CASE 
    WHEN ct.payment_status = 'Paid' THEN 'Complete'
    WHEN pq.status = 'PENDING' THEN 'In Queue'
    WHEN ct.payment_status = 'Pending' THEN 'Awaiting Queue'
    ELSE 'Unknown'
  END AS payment_summary_status,

  -- Time Period Classification
  CASE 
    WHEN DATE(pmo.actual_post_date) >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY) THEN 'This Week'
    WHEN DATE(pmo.actual_post_date) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY) THEN 'This Month'
    WHEN DATE(pmo.actual_post_date) >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY) THEN 'This Quarter'
    ELSE 'Older'
  END AS time_period,

  -- === AGGREGATION HELPERS ===
  1 AS total_posts,
  CASE WHEN pmo.qualified THEN 1 ELSE 0 END AS originally_qualified_posts,
  CASE 
    WHEN COALESCE(sm.latest_impressions, SAFE_CAST(pmo.actual_impressions AS INT64), 0) >= SAFE_CAST(pmo.impressions_target AS INT64)
     AND COALESCE(sm.latest_likes, SAFE_CAST(pmo.actual_likes AS INT64), 0) >= SAFE_CAST(pmo.likes_target AS INT64)
     AND COALESCE(sm.latest_comments, SAFE_CAST(pmo.actual_comments AS INT64), 0) >= SAFE_CAST(pmo.comments_target AS INT64)
    THEN 1 ELSE 0 
  END AS currently_qualified_posts,
  CASE WHEN pmo.screenshot_received THEN 1 ELSE 0 END AS posts_with_screenshots

FROM {{ source('social_media_metrics', 'cleaned_post_metrics_objectives') }} pmo

LEFT JOIN {{ source('social_media_metrics', 'cleaned_contract') }} ct 
  ON pmo.contract_ids = ct.contract_id

LEFT JOIN {{ source('social_media_metrics', 'cleaned_campaigns') }} c 
  ON ct.campaign_id = c.Campaign_id

LEFT JOIN {{ source('social_media_metrics', 'cleaned_customer') }} cust 
  ON ct.influencer_id = cust.Customer_id

LEFT JOIN {{ source('social_media_metrics', 'cleaned_payment_queue') }} pq 
  ON ct.contract_id = pq.contract_id

-- Join latest social media metrics
LEFT JOIN latest_social_metrics sm 
  ON pmo.platform_post_id = sm.platform_post_id 
  AND LOWER(pmo.platform) = LOWER(sm.platform)

-- Join sentiment data for posts
LEFT JOIN post_sentiment ps 
  ON sm.caption = ps.post_text 
  AND LOWER(sm.platform) = LOWER(ps.Platform)

ORDER BY 
  pmo.contract_ids,
  pmo.scheduled_date DESC