-- Performance by Platform (Aggregated Metrics)
SELECT
    platform,
    SUM(total_likes) AS total_likes,
    SUM(total_reach) AS total_reach,
    SUM(total_video_views) AS total_video_views,
    SUM(total_views) AS total_views,
    SUM(total_impressions) AS total_impressions,
    SUM(total_replies) AS total_replies,
    COUNT(DISTINCT post_id) AS total_posts_tracked -- If post_id is consistent across unions
FROM (
    SELECT
        id AS post_id, -- Use a common ID if possible, otherwise NULL
        Platform AS platform,
        like_count AS total_likes,
        reach AS total_reach,
        video_views AS total_video_views,
        views AS total_views,
        NULL AS total_impressions,
        replies AS total_replies
    FROM
        `proof-of-brand.social_media_metrics.cleaned_instagram_data`

    UNION ALL

    SELECT
        tweet_id AS post_id,
        Platform AS platform,
        like_count AS total_likes,
        NULL AS total_reach,
        NULL AS total_video_views,
        NULL AS total_views,
        NULL AS total_impressions,
        reply_count AS total_replies
    FROM
        `proof-of-brand.social_media_metrics.cleaned_tweets_data`

    UNION ALL

    SELECT
        post_id AS post_id,
        platform AS platform,
        actual_likes AS total_likes,
        NULL AS total_reach, -- Add actual_video_views/actual_views if available
        NULL AS total_video_views,
        NULL AS total_views,
        actual_impressions AS total_impressions,
        actual_comments AS total_replies -- Assuming comments are replies in this context
    FROM
        `proof-of-brand.social_media_metrics.cleaned_post_metrics_objectives`
) AS combined_metrics
GROUP BY
    platform
ORDER BY
    platform