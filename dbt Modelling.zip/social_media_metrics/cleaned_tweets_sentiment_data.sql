{{ config(materialized='table') }}

SELECT 
  tweet,
  sentiment,
  confidence,
  Platform
FROM {{ source('social_media_metrics', 'cleaned_tweets_sentiment_data') }}