{{ config(materialized='table') }}

select 
  username,
  permalink,
  id,
  caption,
  timestamp,
  media_type,
  like_count,
  reach,
  video_views,
  plays,
  Platform,
  media_category,
  replies,
  total_interactions,
  views
from social_media_metrics.cleaned_instagram_data  -- your raw BigQuery table name here
